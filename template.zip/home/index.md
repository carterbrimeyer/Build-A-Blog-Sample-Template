---
title: Home
primaryView: home-view
secondaryView: none
viewProperties:
  headshotImage: 'mack.jpg'
---


### Hello.

 This is a sample template for a Build-A-Blog website builder.

 Check out the github for Build-A-Blog [here](https://github.com/cal-overflow/Build-A-Blog).