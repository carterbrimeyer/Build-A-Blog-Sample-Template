---
id: 1
---

### Right Section

This is an example of another section.

This section is cooler than the left section.