---
id: 1
title: Sample Post 1
slug: sample post 1
date: April 5, 2023
img: 'feature-images/blogimage1.jpg'
tags:
  - Build-A-Blog
  - Dogs
---

This is an example of a blog post. The tags for this post are Build-A-Blog and Dogs.

<!--more-->

### What this means...

- You can fill this out however you want!
- Markdown is so cool! Handsome too!
