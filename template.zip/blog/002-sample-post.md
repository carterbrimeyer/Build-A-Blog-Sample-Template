---
id: 2
title: Sample Post 2
slug: sample post 2
date: April 6, 2023
img: 'feature-images/blogimage2.jpg'
tags:
  - Build-A-Blog
  - Cats
---

This is an example of another blog post. The tags for this post are Build-A-Blog and Cats

<!--more-->

### What this means...

- You can fill this out however you want!
- Markdown is so cool! Handsome too!
- This has a different tag from the first sample!
